import java.text.NumberFormat;
import java.util.Objects;

public class Exp implements Function {
    private final Function f;

    public Exp(Function f) {
        this.f = f;
    }

    public double evaluate(double x) {
        return Math.exp(f.evaluate(x));
    }

    public Function derivative() {
        return new Product(f.derivative(), new Exp(f));
    }

    public String toPrettyString(NumberFormat nf) {
        return "exp( " + f.toPrettyString(nf) + " )";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Exp exp = (Exp) o;
        return Objects.equals(f, exp.f);
    }

    @Override
    public int hashCode() {
        return Objects.hash(f);
    }

}
