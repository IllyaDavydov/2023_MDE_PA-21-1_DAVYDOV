import java.text.NumberFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of x: ");
        double x = scanner.nextDouble();
        final Function expression =
                new Sum(
                        new Exp(
                            new Product(
                                    new Constant(-2.0),
                                    new Pow(
                                            new Cos(Variable.X),
                                        2.0
                                )
                        )
                ),
                new Product(
                        new Constant(-1.0),
                        new Abs(
                                new Product(
                                        new Constant(3.0),
                                        new Pow(
                                                new Ln(new Sqrt(Variable.X)),
                                                5.0
                                        )
                                )
                        )
                        ));

        final Function expression2 =
                (
                        new Product(
                                new Product(
                                        new Constant(-2),
                                        new Pow(
                                                Variable.X,
                                                3
                                        )
                                ),
                                new Pow(
                                        new Pow(
                                                new Sin(
                                                        new Sum(
                                                                Variable.X,
                                                                new Constant(3)
                                                        )
                                                ),
                                                        2
                                        ),
                                        -1)
                        )
                );

        final NumberFormat nf = NumberFormat.getInstance();
        System.out.format("f1(x) = %s", expression.toPrettyString(nf)).println();
        System.out.format("f1'(x) = %s", expression.derivative().toPrettyString(nf)).println();
        System.out.format("f1(" + x +") = %f", expression.evaluate(x)).println();
        System.out.format("f1'(" + x + ") = %f", expression.derivative().evaluate(x)).println();
        System.out.format("f2(x) = %s", expression2.toPrettyString(nf)).println();
        System.out.format("f2'(x) = %s", expression2.derivative().toPrettyString(nf)).println();
        System.out.format("f2(" + x +") = %f", expression2.evaluate(x)).println();
        System.out.format("f2'(" + x + ") = %f", expression2.derivative().evaluate(x)).println();
    }

}