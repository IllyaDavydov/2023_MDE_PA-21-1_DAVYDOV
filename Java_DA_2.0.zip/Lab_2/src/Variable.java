import java.text.NumberFormat;
import java.util.Objects;

class Variable implements Function {
    public static final Variable X = new Variable();
    public double evaluate(double x) {
        return x;
    }

    public Function derivative() {
        return new Constant(1);
    }

    @Override
    public String toPrettyString(NumberFormat nf){
        return "x";
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Variable Variable = (Variable) o;
        return Objects.equals(X, Variable.X);
    }

    @Override
    public int hashCode() {
        return Objects.hash(X);
    }
}