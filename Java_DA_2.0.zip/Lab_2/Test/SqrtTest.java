import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;

public class SqrtTest {
    @Test
    public void SqrtTestPositive(){
        final double inputValue = 9;
        final double expectedValue = 3;

        final Sqrt sqrt = new Sqrt(new Constant(inputValue));
        final double actualResult = sqrt.evaluate(1);
        Assertions.assertEquals(actualResult, expectedValue, 1e-6);

    }

    @Test
    public void SqrtTestDerivative(){
        final Function inputFunction = Variable.X;
        final Function expectedDerivative = new Product(new Pow(inputFunction, -0.5), new Constant(0.5));

        final Sqrt sqrt = new Sqrt(inputFunction);

        double x = 4.0;
        double epsilon = 1e-6;

        double expectedValue = expectedDerivative.evaluate(x);
        double actualValue = sqrt.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void SqrtTestToPrettyString(){
        final Function inputFunction = Variable.X;
        final Function sqrtFunction = new Sqrt(inputFunction);

        final NumberFormat nf = NumberFormat.getInstance();
        final String expectedString = "sqrt( x )";
        Assertions.assertEquals(sqrtFunction.toPrettyString(nf), expectedString);
    }
}
