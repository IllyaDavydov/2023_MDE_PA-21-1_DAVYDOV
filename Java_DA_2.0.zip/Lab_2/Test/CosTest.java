import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;
public class CosTest {
    @Test
    public void CosTestZero(){
        final double inputZeroValue = 0;
        final double desiredValue = 1;

        final Cos cos = new Cos(Variable.X);
        final double actualResult = cos.evaluate(inputZeroValue);
        Assertions.assertEquals(actualResult, desiredValue);

    }

    @Test
    public void CosTestPositive(){
        final double inputPositiveValue = Math.PI/4;
        final double desiredValue = Math.sqrt(2)/2;

        final Cos cos = new Cos(Variable.X);
        final double actualResult = cos.evaluate(inputPositiveValue);
        Assertions.assertEquals(actualResult, desiredValue);

    }

    @Test
    public void CosTestDerivative(){
        final Function determine = new Cos(Variable.X);
        final Function actualResult = new Product(new Constant(-1), new Sin(Variable.X));

        double x = Math.PI/6;
        double epsilon = 1e-6;

        double expectedValue = actualResult.evaluate(x);
        double actualValue = determine.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void CosTestToPrettyString(){
        final Function determine = new Cos(Variable.X);
        final NumberFormat nf = NumberFormat.getInstance();
        final String actualResult = "cos(x)";
        Assertions.assertEquals(determine.toPrettyString(nf), actualResult);
    }
}