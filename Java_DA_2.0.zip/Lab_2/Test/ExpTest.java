import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;

public class ExpTest {
    public void ExpTestZero(){
        final double inputZeroValue = 0;
        final double desiredValue = 1;

        final Exp exp = new Exp(Variable.X);
        final double actualResult = exp.evaluate(inputZeroValue);
        Assertions.assertEquals(actualResult, desiredValue);

    }

    @Test
    public void ExpTestPositive(){
        final double inputPositiveValue = 1;
        final double desiredValue = Math.E;

        final Exp exp = new Exp(Variable.X);
        final double actualResult = exp.evaluate(inputPositiveValue);
        Assertions.assertEquals(actualResult, desiredValue);

    }

    @Test
    public void ExpTestNegative(){
        final double inputNegativeValue = -1;
        final double desiredValue = 1/Math.E;

        final Exp exp = new Exp(Variable.X);
        final double actualResult = exp.evaluate(inputNegativeValue);
        Assertions.assertEquals(actualResult, desiredValue);

    }

    @Test
    public void ExpTestDerivative(){
        final Function determine = new Exp(Variable.X);
        final Function actualResult = new Exp(Variable.X);

        double x = 2.0;
        double epsilon = 1e-6;

        double expectedValue = actualResult.evaluate(x);
        double actualValue = determine.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void ExpTestToPrettyString(){
        final Function determine = new Exp(Variable.X);
        final NumberFormat nf = NumberFormat.getInstance();
        final String actualResult = "exp( x )";
        Assertions.assertEquals(determine.toPrettyString(nf), actualResult);
    }
}
