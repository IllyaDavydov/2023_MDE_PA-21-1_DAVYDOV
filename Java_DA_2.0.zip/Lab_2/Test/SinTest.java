import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;

public class SinTest {
    @Test
    public void SinTestZero(){
        final double inputZeroValue = 0;
        final double desiredValue = 0;

        final Sin sin = new Sin(Variable.X);
        final double actualResult = sin.evaluate(inputZeroValue);
        Assertions.assertEquals(actualResult, desiredValue, 1e-6);

    }

    @Test
    public void SinTestPositive(){
        final double inputPositiveValue = Math.PI/6;
        final double desiredValue = 0.5;

        final Sin sin = new Sin(Variable.X);
        final double actualResult = sin.evaluate(inputPositiveValue);
        Assertions.assertEquals(actualResult, desiredValue, 1e-6);

    }

    @Test
    public void SinTestNegative(){
        final double inputNegativeValue = -Math.PI/3;
        final double desiredValue = -Math.sqrt(3)/2;

        final Sin sin = new Sin(Variable.X);
        final double actualResult = sin.evaluate(inputNegativeValue);
        Assertions.assertEquals(actualResult, desiredValue, 1e-6);

    }

    @Test
    public void SinTestDerivative(){
        final Function determine = new Sin(Variable.X);
        final Function actualResult = new Cos(Variable.X);

        double x = Math.PI/4;
        double epsilon = 1e-6;

        double expectedValue = actualResult.evaluate(x);
        double actualValue = determine.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void SinTestToPrettyString(){
        final Function determine = new Sin(Variable.X);
        final NumberFormat nf = NumberFormat.getInstance();
        final String actualResult = "sin(x)";
        Assertions.assertEquals(determine.toPrettyString(nf), actualResult);
    }
}
