import org.junit.jupiter.api.Assertions;

public class SumTest {
    public void AddTestPositive(){
        final double num1 = 2;
        final double num2 = 3;
        final Sum add = new Sum(new Constant(num1), new Constant(num2));
        final double expectedValue = num1 + num2;

        final double actualResult = add.evaluate(0);
        Assertions.assertEquals(expectedValue, actualResult, 1e-6);
    }
}
