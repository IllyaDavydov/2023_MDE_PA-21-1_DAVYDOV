import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;

public class LnTest {
    @Test
    public void LnTestPositive(){
        final double inputValue = 4;
        final Function inputFunction = new Constant(inputValue);
        final double expectedValue = Math.log(inputValue);

        final Ln ln = new Ln(inputFunction);
        final double actualResult = ln.evaluate(1);
        Assertions.assertEquals(actualResult, expectedValue, 1e-6);

    }

    @Test
    public void LnTestDerivative(){
        final Function inputFunction = Variable.X;
        final Function expectedDerivative = new Product(new Pow(inputFunction, -1), new Constant(1));

        final Ln ln = new Ln(inputFunction);

        double x = 2.0;
        double epsilon = 1e-6;

        double expectedValue = expectedDerivative.evaluate(x);
        double actualValue = ln.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void LnTestToPrettyString(){
        final Function inputFunction = Variable.X;
        final Function lnFunction = new Ln(inputFunction);

        final NumberFormat nf = NumberFormat.getInstance();
        final String expectedString = "ln(x)";
        Assertions.assertEquals(lnFunction.toPrettyString(nf), expectedString);
    }
}
