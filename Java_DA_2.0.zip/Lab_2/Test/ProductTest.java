import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ProductTest {
    @Test
    public void MultiplyTestPositive(){
        final double num1 = 2;
        final double num2 = 3;
        final Product multiply = new Product(new Constant(num1), new Constant(num2));
        final double expectedValue = num1 * num2;

        final double actualResult = multiply.evaluate(0);
        Assertions.assertEquals(actualResult, expectedValue, 1e-6);
    }
}
