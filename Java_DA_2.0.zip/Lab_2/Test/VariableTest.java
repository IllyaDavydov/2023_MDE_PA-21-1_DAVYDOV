import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class VariableTest {
    @Test
    public void VariableTestEvaluate(){
        final double varValue = 3.14;

        final Variable var = Variable.X;
        final double actualResult = var.evaluate(varValue);

        Assertions.assertEquals(varValue, actualResult, 1e-6);
    }
}
