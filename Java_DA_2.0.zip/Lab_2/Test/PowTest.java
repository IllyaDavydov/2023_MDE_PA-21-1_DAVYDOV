import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.NumberFormat;

public class PowTest {
    @Test
    public void PowTestPositive(){
        final double baseValue = 2;
        final Function base = new Constant(baseValue);
        final double expectedValue = Math.pow(baseValue, 3);

        final Pow pow = new Pow(base, 3);
        final double actualResult = pow.evaluate(1);
        Assertions.assertEquals(actualResult, expectedValue, 1e-6);

    }

    @Test
    public void PowTestDerivative(){
        final Function base = Variable.X;
        final Function expectedDerivative = new Product(new Constant(2), base);

        final Pow pow = new Pow(base, 2);

        double x = 2.0;
        double epsilon = 1e-6;

        double expectedValue = expectedDerivative.evaluate(x);
        double actualValue = pow.derivative().evaluate(x);

        Assertions.assertEquals(expectedValue, actualValue, epsilon);
    }

    @Test
    public void PowTestToPrettyString(){
        final Function base = Variable.X;
        final Function powFunction = new Pow(base, 2);

        final NumberFormat nf = NumberFormat.getInstance();
        final String expectedString = "(x^2.0)";
        Assertions.assertEquals(powFunction.toPrettyString(nf), expectedString);
    }
}
